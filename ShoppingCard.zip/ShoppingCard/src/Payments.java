
public enum Payments {
	 FIXED,
	 PER_HOUR,
	 WITH_REGISTRATION_PRICE
}
